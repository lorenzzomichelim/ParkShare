import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import HowItWorks from "./components/HowItWorks";
import FeaturedListings from "./components/FeaturedListings";
import ForOwners from "./components/ForOwners";
import MapSection from "./components/MapSection";
import Pricing from "./components/Pricing";
import Testimonials from "./components/Testimonials";
import FAQ from "./components/FAQ";
import CTA from "./components/CTA";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="font-['Inter',sans-serif] antialiased">
      <Navbar />
      <Hero />
      <HowItWorks />
      <FeaturedListings />
      <ForOwners />
      <MapSection />
      <Pricing />
      <Testimonials />
      <FAQ />
      <CTA />
      <Footer />
    </div>
  );
}
