export default function Footer() {
  const links = {
    Produto: [
      "Como Funciona",
      "Para Motoristas",
      "Para Proprietários",
      "Preços",
      "App Mobile",
    ],
    Empresa: [
      "Sobre Nós",
      "Carreiras",
      "Blog",
      "Imprensa",
      "Contato",
    ],
    Suporte: [
      "Central de Ajuda",
      "Segurança",
      "Seguros",
      "Cancelamentos",
      "Chat ao Vivo",
    ],
    Legal: [
      "Termos de Uso",
      "Privacidade",
      "Cookies",
      "LGPD",
    ],
  };

  return (
    <footer className="bg-gray-950 text-gray-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Top */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-10 mb-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-md">
                <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <span className="text-xl font-bold text-white">
                Park<span className="text-emerald-400">Share</span>
              </span>
            </div>
            <p className="text-sm leading-relaxed mb-4">
              O marketplace de vagas privadas mais confiável do Brasil. Conectamos motoristas a proprietários desde 2024.
            </p>
            {/* Social */}
            <div className="flex gap-3">
              {["instagram", "twitter", "linkedin", "youtube"].map((social) => (
                <a
                  key={social}
                  href="#"
                  className="w-8 h-8 rounded-lg bg-white/5 hover:bg-emerald-500/20 hover:text-emerald-400 flex items-center justify-center transition-all text-xs font-bold uppercase"
                >
                  {social[0].toUpperCase()}
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(links).map(([category, items]) => (
            <div key={category}>
              <h4 className="text-white font-semibold text-sm mb-4">{category}</h4>
              <ul className="space-y-2.5">
                {items.map((item) => (
                  <li key={item}>
                    <a href="#" className="text-sm hover:text-emerald-400 transition-colors">
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Divider */}
        <div className="border-t border-white/5 pt-8">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-xs">
              © 2025 ParkShare Tecnologia Ltda. Todos os direitos reservados.
            </p>
            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                Todos os sistemas operacionais
              </span>
              <span>CNPJ: 00.000.000/0001-00</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
