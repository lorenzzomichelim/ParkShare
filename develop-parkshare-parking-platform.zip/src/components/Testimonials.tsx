const testimonials = [
  {
    name: "Fernanda Oliveira",
    role: "Proprietária de vaga • São Paulo, SP",
    avatar: "FO",
    avatarColor: "bg-emerald-500",
    rating: 5,
    text: "Minha vaga ficava vazia a semana toda. Hoje recebo R$ 1.400 por mês sem fazer absolutamente nada. O cadastro foi fácil e o suporte é incrível.",
    earnings: "R$ 1.400/mês",
  },
  {
    name: "Carlos Eduardo",
    role: "Motorista • Curitiba, PR",
    avatar: "CE",
    avatarColor: "bg-blue-500",
    rating: 5,
    text: "Trabalho no centro de Curitiba e o estacionamento era um pesadelo. Com o ParkShare pago R$ 12/hora numa garagem coberta a 2 minutos do escritório. Mudou minha vida!",
    earnings: null,
  },
  {
    name: "Roberto Maia",
    role: "Proprietário de 3 vagas • Rio de Janeiro, RJ",
    avatar: "RM",
    avatarColor: "bg-purple-500",
    rating: 5,
    text: "Comecei com uma vaga, gostei tanto que cadastrei mais duas do meu condomínio. Agora tenho uma renda complementar de quase R$ 4.000 por mês. Simplesmente incrível.",
    earnings: "R$ 3.900/mês",
  },
  {
    name: "Ana Beatriz Santos",
    role: "Motorista • Belo Horizonte, MG",
    avatar: "AB",
    avatarColor: "bg-rose-500",
    rating: 5,
    text: "Fui num show e achei uma vaga a R$ 8 a hora a 5 minutos do local. O pagamento foi pelo app e recebi um código de acesso. Perfeito, sem estresse nenhum.",
    earnings: null,
  },
  {
    name: "Marcelo Cunha",
    role: "Proprietário • Brasília, DF",
    avatar: "MC",
    avatarColor: "bg-orange-500",
    rating: 5,
    text: "Tenho uma vaga numa rua movimentada em Brasília. O ParkShare cuida de tudo: cobrança, suporte ao cliente, seguros. Só recebo o dinheiro.",
    earnings: "R$ 900/mês",
  },
  {
    name: "Juliana Ferreira",
    role: "Motorista • Porto Alegre, RS",
    avatar: "JF",
    avatarColor: "bg-teal-500",
    rating: 5,
    text: "Tenho uma reunião toda semana no mesmo lugar. Agora assino uma vaga mensalmente pelo ParkShare. Saio de casa já sabendo onde vou parar. Amei!",
    earnings: null,
  },
];

function Stars({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: count }).map((_, i) => (
        <svg key={i} className="w-4 h-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  );
}

export default function Testimonials() {
  return (
    <section id="depoimentos" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-emerald-600 font-semibold text-sm uppercase tracking-widest mb-3">
            Depoimentos
          </span>
          <h2 className="text-4xl font-black text-gray-900 mb-4">
            Quem usa, aprova
          </h2>
          <p className="text-lg text-gray-500 max-w-2xl mx-auto">
            Mais de 50.000 usuários ativos em todo o Brasil. Veja o que eles estão falando.
          </p>
        </div>

        {/* Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="bg-gray-50 hover:bg-white border border-gray-100 hover:border-emerald-100 hover:shadow-lg rounded-2xl p-6 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full ${t.avatarColor} flex items-center justify-center text-white text-sm font-bold shrink-0`}>
                    {t.avatar}
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900 text-sm">{t.name}</div>
                    <div className="text-gray-400 text-xs">{t.role}</div>
                  </div>
                </div>
                {t.earnings && (
                  <div className="bg-emerald-100 text-emerald-700 text-xs font-bold px-2 py-1 rounded-lg shrink-0 ml-2">
                    {t.earnings}
                  </div>
                )}
              </div>

              <Stars count={t.rating} />

              <p className="text-gray-600 text-sm leading-relaxed mt-3">"{t.text}"</p>
            </div>
          ))}
        </div>

        {/* Trust badges */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { value: "50K+", label: "Usuários ativos" },
            { value: "12K+", label: "Vagas cadastradas" },
            { value: "4.9/5", label: "Avaliação nas lojas" },
            { value: "R$2M+", label: "Pagos a proprietários" },
          ].map((stat, i) => (
            <div key={i} className="text-center py-6 border border-gray-100 rounded-2xl hover:border-emerald-200 transition-colors">
              <div className="text-3xl font-black text-emerald-600 mb-1">{stat.value}</div>
              <div className="text-gray-500 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
