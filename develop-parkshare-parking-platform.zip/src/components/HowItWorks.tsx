const driverSteps = [
  {
    icon: "🔍",
    step: "01",
    title: "Busque no mapa",
    desc: "Digite o endereço ou use sua localização para encontrar vagas disponíveis perto de você em tempo real.",
  },
  {
    icon: "📅",
    step: "02",
    title: "Reserve com antecedência",
    desc: "Escolha o horário de chegada e saída, filtre por tipo de vaga e confirme sua reserva em segundos.",
  },
  {
    icon: "💳",
    step: "03",
    title: "Pague com segurança",
    desc: "Pagamento 100% digital via PIX, cartão ou carteira digital. Recibo digital automático.",
  },
  {
    icon: "🚗",
    step: "04",
    title: "Estacione tranquilo",
    desc: "Receba o endereço exato e instruções de acesso. Chegue e estacione sem filas ou estresse.",
  },
];

const ownerSteps = [
  {
    icon: "📋",
    step: "01",
    title: "Cadastre sua vaga",
    desc: "Adicione fotos, endereço, tipo e disponibilidade da sua vaga. Leva menos de 5 minutos.",
  },
  {
    icon: "💰",
    step: "02",
    title: "Defina seu preço",
    desc: "Você escolhe o valor por hora, dia ou mês. Sugerimos preços com base no mercado local.",
  },
  {
    icon: "📱",
    step: "03",
    title: "Receba reservas",
    desc: "Notificação imediata para cada reserva. Você aprova ou rejeita com um toque.",
  },
  {
    icon: "💵",
    step: "04",
    title: "Receba o pagamento",
    desc: "O valor cai na sua conta via PIX em até 24h após cada reserva concluída. Simples assim.",
  },
];

export default function HowItWorks() {
  return (
    <section id="como-funciona" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-emerald-600 font-semibold text-sm uppercase tracking-widest mb-3">
            Como Funciona
          </span>
          <h2 className="text-4xl font-black text-gray-900 mb-4">
            Simples para todos os lados
          </h2>
          <p className="text-lg text-gray-500 max-w-2xl mx-auto">
            Seja você um motorista buscando vaga ou um proprietário querendo renda extra, o ParkShare funciona de forma rápida e intuitiva.
          </p>
        </div>

        {/* For Drivers */}
        <div className="mb-20">
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-xl">🚗</div>
            <h3 className="text-2xl font-bold text-gray-900">Para Motoristas</h3>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {driverSteps.map((step, i) => (
              <div key={i} className="relative">
                {i < driverSteps.length - 1 && (
                  <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-emerald-200 to-transparent z-0" style={{ width: "calc(100% - 2rem)" }} />
                )}
                <div className="relative bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md hover:border-emerald-100 transition-all group">
                  <div className="flex items-start justify-between mb-4">
                    <div className="text-3xl">{step.icon}</div>
                    <span className="text-4xl font-black text-gray-100 group-hover:text-emerald-100 transition-colors">
                      {step.step}
                    </span>
                  </div>
                  <h4 className="font-bold text-gray-900 mb-2">{step.title}</h4>
                  <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* For Owners */}
        <div>
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center text-xl">🏠</div>
            <h3 className="text-2xl font-bold text-gray-900">Para Proprietários</h3>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {ownerSteps.map((step, i) => (
              <div key={i} className="relative bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl p-6 border border-emerald-100 hover:border-emerald-200 hover:shadow-md transition-all group">
                <div className="flex items-start justify-between mb-4">
                  <div className="text-3xl">{step.icon}</div>
                  <span className="text-4xl font-black text-emerald-100 group-hover:text-emerald-200 transition-colors">
                    {step.step}
                  </span>
                </div>
                <h4 className="font-bold text-gray-900 mb-2">{step.title}</h4>
                <p className="text-gray-500 text-sm leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
