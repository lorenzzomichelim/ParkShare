import { useState } from "react";

export default function Hero() {
  const [tab, setTab] = useState<"encontrar" | "anunciar">("encontrar");

  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.pexels.com/photos/16896042/pexels-photo-16896042.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          alt="Estacionamento urbano noturno"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-gray-950/90 via-gray-900/80 to-emerald-950/70" />
      </div>

      {/* Animated blobs */}
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-teal-400/10 rounded-full blur-2xl animate-pulse delay-1000" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column */}
          <div>
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 border border-emerald-500/30 rounded-full px-4 py-1.5 mb-6 backdrop-blur-sm">
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
              <span className="text-emerald-300 text-sm font-medium">+12.000 vagas disponíveis no Brasil</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white leading-tight mb-6">
              Sua vaga parada{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
                vale dinheiro.
              </span>
            </h1>

            <p className="text-lg text-gray-300 leading-relaxed mb-8 max-w-xl">
              O <strong className="text-white">ParkShare</strong> conecta motoristas a vagas privadas particulares. 
              Alugue por hora, dia ou mês — com segurança, praticidade e preço justo.
            </p>

            <div className="flex flex-wrap gap-4 mb-10">
              <div className="flex items-center gap-2 text-gray-300 text-sm">
                <svg className="w-5 h-5 text-emerald-400 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
                Sem burocracia
              </div>
              <div className="flex items-center gap-2 text-gray-300 text-sm">
                <svg className="w-5 h-5 text-emerald-400 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
                Pagamento seguro
              </div>
              <div className="flex items-center gap-2 text-gray-300 text-sm">
                <svg className="w-5 h-5 text-emerald-400 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
                Cancelamento flexível
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              {[
                { value: "12K+", label: "Vagas cadastradas" },
                { value: "R$2M+", label: "Pagos aos donos" },
                { value: "4.9★", label: "Avaliação média" },
              ].map((stat) => (
                <div key={stat.label} className="text-center">
                  <div className="text-2xl font-black text-white">{stat.value}</div>
                  <div className="text-xs text-gray-400 mt-0.5">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column – Search Card */}
          <div className="bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20 p-6 shadow-2xl">
            {/* Tabs */}
            <div className="flex rounded-2xl bg-white/10 p-1 mb-6">
              <button
                onClick={() => setTab("encontrar")}
                className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  tab === "encontrar"
                    ? "bg-white text-gray-900 shadow-md"
                    : "text-white/70 hover:text-white"
                }`}
              >
                🚗 Encontrar Vaga
              </button>
              <button
                onClick={() => setTab("anunciar")}
                className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  tab === "anunciar"
                    ? "bg-white text-gray-900 shadow-md"
                    : "text-white/70 hover:text-white"
                }`}
              >
                💰 Anunciar Vaga
              </button>
            </div>

            {tab === "encontrar" ? (
              <div className="space-y-4">
                <div>
                  <label className="text-white/80 text-xs font-semibold uppercase tracking-wider mb-1.5 block">Localização</label>
                  <div className="relative">
                    <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    </svg>
                    <input
                      type="text"
                      placeholder="Rua, bairro ou ponto de referência..."
                      className="w-full bg-white text-gray-900 pl-10 pr-4 py-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-white/80 text-xs font-semibold uppercase tracking-wider mb-1.5 block">Chegada</label>
                    <input
                      type="datetime-local"
                      className="w-full bg-white text-gray-700 px-3 py-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="text-white/80 text-xs font-semibold uppercase tracking-wider mb-1.5 block">Saída</label>
                    <input
                      type="datetime-local"
                      className="w-full bg-white text-gray-700 px-3 py-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-white/80 text-xs font-semibold uppercase tracking-wider mb-1.5 block">Tipo de vaga</label>
                  <select className="w-full bg-white text-gray-700 px-3 py-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500">
                    <option>Qualquer tipo</option>
                    <option>Coberta</option>
                    <option>Descoberta</option>
                    <option>Garagem</option>
                    <option>Subsolo</option>
                  </select>
                </div>

                <button className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-4 rounded-xl transition-all shadow-lg hover:shadow-emerald-500/30 active:scale-95 text-sm">
                  🔍 Buscar Vagas Disponíveis
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="text-white/80 text-xs font-semibold uppercase tracking-wider mb-1.5 block">Endereço da vaga</label>
                  <input
                    type="text"
                    placeholder="Endereço completo da vaga..."
                    className="w-full bg-white text-gray-900 px-4 py-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-white/80 text-xs font-semibold uppercase tracking-wider mb-1.5 block">Preço por hora (R$)</label>
                  <input
                    type="number"
                    placeholder="Ex: 8,00"
                    className="w-full bg-white text-gray-900 px-4 py-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-white/80 text-xs font-semibold uppercase tracking-wider mb-1.5 block">Tipo de vaga</label>
                  <select className="w-full bg-white text-gray-700 px-3 py-3 rounded-xl text-sm outline-none focus:ring-2 focus:ring-emerald-500">
                    <option>Selecione...</option>
                    <option>Coberta</option>
                    <option>Descoberta</option>
                    <option>Garagem</option>
                    <option>Subsolo</option>
                  </select>
                </div>
                <div className="bg-emerald-500/20 border border-emerald-500/30 rounded-xl p-3">
                  <p className="text-emerald-300 text-xs font-medium">
                    💡 Vagas em São Paulo rendem em média <strong className="text-white">R$ 1.200/mês</strong>
                  </p>
                </div>
                <button className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-4 rounded-xl transition-all shadow-lg hover:shadow-emerald-500/30 active:scale-95 text-sm">
                  💰 Cadastrar Minha Vaga Grátis
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <svg className="w-6 h-6 text-white/40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </div>
    </section>
  );
}
