const cities = [
  { name: "São Paulo", count: "4.200+", emoji: "🏙️" },
  { name: "Rio de Janeiro", count: "2.100+", emoji: "🌊" },
  { name: "Belo Horizonte", count: "980+", emoji: "⛰️" },
  { name: "Curitiba", count: "870+", emoji: "🌲" },
  { name: "Brasília", count: "750+", emoji: "🏛️" },
  { name: "Porto Alegre", count: "620+", emoji: "🌉" },
  { name: "Salvador", count: "540+", emoji: "☀️" },
  { name: "Fortaleza", count: "480+", emoji: "🌴" },
];

export default function MapSection() {
  return (
    <section className="py-24 bg-gradient-to-br from-gray-900 via-gray-900 to-emerald-950 overflow-hidden relative">
      {/* Decorative */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-teal-400/5 rounded-full blur-2xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left */}
          <div>
            <span className="inline-block text-emerald-400 font-semibold text-sm uppercase tracking-widest mb-3">
              Cobertura Nacional
            </span>
            <h2 className="text-4xl font-black text-white mb-4 leading-tight">
              Presente nas{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
                principais cidades
              </span>{" "}
              do Brasil
            </h2>
            <p className="text-gray-400 text-lg mb-8 leading-relaxed">
              Com mais de 12.000 vagas cadastradas e expansão constante, o ParkShare 
              está em mais de 50 cidades brasileiras — e crescendo todo mês.
            </p>

            <div className="flex flex-wrap gap-3 mb-10">
              <div className="bg-emerald-500/20 border border-emerald-500/30 rounded-xl px-4 py-2">
                <span className="text-emerald-300 font-bold text-2xl">50+</span>
                <span className="text-gray-400 text-sm ml-2">cidades</span>
              </div>
              <div className="bg-white/10 border border-white/10 rounded-xl px-4 py-2">
                <span className="text-white font-bold text-2xl">12K+</span>
                <span className="text-gray-400 text-sm ml-2">vagas</span>
              </div>
              <div className="bg-white/10 border border-white/10 rounded-xl px-4 py-2">
                <span className="text-white font-bold text-2xl">24/7</span>
                <span className="text-gray-400 text-sm ml-2">disponível</span>
              </div>
            </div>

            <a
              href="#"
              className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-6 py-3.5 rounded-xl transition-all shadow-lg"
            >
              Ver mapa completo
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
          </div>

          {/* Right – City Grid */}
          <div className="grid grid-cols-2 gap-3">
            {cities.map((city, i) => (
              <div
                key={i}
                className="bg-white/5 hover:bg-white/10 border border-white/10 hover:border-emerald-500/30 rounded-2xl p-4 transition-all cursor-pointer group"
              >
                <div className="text-2xl mb-2">{city.emoji}</div>
                <div className="font-semibold text-white text-sm group-hover:text-emerald-400 transition-colors">{city.name}</div>
                <div className="text-emerald-400 text-xs font-bold mt-0.5">{city.count} vagas</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
