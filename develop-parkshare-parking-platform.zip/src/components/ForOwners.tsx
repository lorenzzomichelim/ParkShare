const benefits = [
  {
    icon: "📈",
    title: "Renda Passiva Real",
    desc: "Transforme sua vaga ociosa em uma fonte de renda mensal consistente. Proprietários ganham em média R$ 800 a R$ 2.000/mês.",
  },
  {
    icon: "🔒",
    title: "100% Seguro",
    desc: "Todos os motoristas são verificados. Seguro contra danos incluído em cada reserva sem custo adicional para você.",
  },
  {
    icon: "📱",
    title: "Controle Total",
    desc: "Você define a disponibilidade, preço e quem pode usar sua vaga. Bloqueie datas quando precisar usar.",
  },
  {
    icon: "⚡",
    title: "Pagamento Rápido",
    desc: "Receba via PIX em até 24h após cada reserva. Histórico completo de transações no app.",
  },
  {
    icon: "📊",
    title: "Dashboard Inteligente",
    desc: "Acompanhe reservas, ganhos, avaliações e estatísticas da sua vaga em tempo real.",
  },
  {
    icon: "🆓",
    title: "Cadastro Gratuito",
    desc: "Cadastrar sua vaga é grátis. A ParkShare cobra apenas uma taxa de serviço sobre cada reserva concluída.",
  },
];

export default function ForOwners() {
  return (
    <section id="proprietarios" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left */}
          <div>
            <span className="inline-block text-emerald-600 font-semibold text-sm uppercase tracking-widest mb-3">
              Para Proprietários
            </span>
            <h2 className="text-4xl font-black text-gray-900 mb-4 leading-tight">
              Sua vaga parada custa dinheiro.{" "}
              <span className="text-emerald-500">Coloque ela para trabalhar.</span>
            </h2>
            <p className="text-gray-500 text-lg leading-relaxed mb-8">
              Milhares de motoristas precisam de vaga todos os dias. Com o ParkShare, sua garagem, vaga de condomínio ou 
              terreno gera renda enquanto você não está usando.
            </p>

            {/* Earning Simulator */}
            <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-6 text-white mb-8 shadow-xl shadow-emerald-200">
              <h3 className="font-bold text-lg mb-4">💡 Simulador de Ganhos</h3>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: "8h/dia × R$10", period: "Ganho diário", value: "R$ 80" },
                  { label: "5 dias/semana", period: "Ganho semanal", value: "R$ 400" },
                  { label: "Desconto 15%*", period: "Taxa ParkShare", value: "R$ 60" },
                  { label: "Líquido para você", period: "Ganho mensal líquido", value: "R$ 1.360" },
                ].map((item, i) => (
                  <div key={i} className={`rounded-xl p-3 ${i === 3 ? "bg-white/30 col-span-2" : "bg-white/20"}`}>
                    <div className={`font-black ${i === 3 ? "text-3xl" : "text-xl"}`}>{item.value}</div>
                    <div className="text-white/80 text-xs mt-0.5">{item.period}</div>
                    <div className="text-white/60 text-xs">{item.label}</div>
                  </div>
                ))}
              </div>
              <p className="text-white/60 text-xs mt-3">*Taxa de serviço da plataforma de 15% sobre cada transação.</p>
            </div>

            <a
              href="#"
              className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-8 py-4 rounded-xl transition-all shadow-lg hover:shadow-emerald-200 active:scale-95"
            >
              Anunciar Minha Vaga Agora
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
          </div>

          {/* Right – Benefits Grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            {benefits.map((b, i) => (
              <div
                key={i}
                className="bg-gray-50 hover:bg-emerald-50 border border-gray-100 hover:border-emerald-200 rounded-2xl p-5 transition-all group"
              >
                <div className="text-3xl mb-3">{b.icon}</div>
                <h4 className="font-bold text-gray-900 mb-1 text-sm">{b.title}</h4>
                <p className="text-gray-500 text-xs leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
