const plans = [
  {
    name: "Básico",
    tag: null,
    price: "Grátis",
    period: "para sempre",
    color: "gray",
    desc: "Ideal para quem está começando e quer testar a plataforma.",
    features: [
      { text: "1 vaga cadastrada", ok: true },
      { text: "Reservas ilimitadas", ok: true },
      { text: "Taxa de 20% por reserva", ok: true },
      { text: "Pagamento via PIX", ok: true },
      { text: "Dashboard básico", ok: true },
      { text: "Seguro por reserva", ok: false },
      { text: "Suporte prioritário", ok: false },
      { text: "Analytics avançado", ok: false },
    ],
    cta: "Começar grátis",
    ctaStyle: "border border-gray-200 text-gray-700 hover:bg-gray-50",
  },
  {
    name: "Pro",
    tag: "Mais popular",
    price: "R$ 29",
    period: "por mês",
    color: "emerald",
    desc: "Para proprietários que querem maximizar sua renda com vagas.",
    features: [
      { text: "Até 5 vagas cadastradas", ok: true },
      { text: "Reservas ilimitadas", ok: true },
      { text: "Taxa de 15% por reserva", ok: true },
      { text: "Todos os métodos de pagamento", ok: true },
      { text: "Dashboard completo", ok: true },
      { text: "Seguro em todas as reservas", ok: true },
      { text: "Suporte prioritário 24/7", ok: true },
      { text: "Analytics avançado", ok: false },
    ],
    cta: "Assinar Pro",
    ctaStyle: "bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg hover:shadow-emerald-200",
  },
  {
    name: "Business",
    tag: null,
    price: "R$ 99",
    period: "por mês",
    color: "gray",
    desc: "Para estacionamentos e empresas com múltiplas vagas.",
    features: [
      { text: "Vagas ilimitadas", ok: true },
      { text: "Reservas ilimitadas", ok: true },
      { text: "Taxa de 10% por reserva", ok: true },
      { text: "Todos os métodos de pagamento", ok: true },
      { text: "Dashboard empresarial", ok: true },
      { text: "Seguro premium incluído", ok: true },
      { text: "Gerente de conta dedicado", ok: true },
      { text: "Analytics avançado + relatórios", ok: true },
    ],
    cta: "Falar com vendas",
    ctaStyle: "border border-gray-200 text-gray-700 hover:bg-gray-50",
  },
];

export default function Pricing() {
  return (
    <section id="precos" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-emerald-600 font-semibold text-sm uppercase tracking-widest mb-3">
            Planos & Preços
          </span>
          <h2 className="text-4xl font-black text-gray-900 mb-4">
            Transparente do início ao fim
          </h2>
          <p className="text-lg text-gray-500 max-w-2xl mx-auto">
            Sem taxas escondidas. Você sabe exatamente o que paga e o que recebe.
            Comece grátis e escale conforme cresce.
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan, i) => (
            <div
              key={i}
              className={`relative bg-white rounded-3xl p-8 border transition-all hover:shadow-xl ${
                plan.color === "emerald"
                  ? "border-emerald-500 shadow-lg shadow-emerald-100 scale-105"
                  : "border-gray-100 hover:border-gray-200"
              }`}
            >
              {plan.tag && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                  <span className="bg-emerald-500 text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-md">
                    {plan.tag}
                  </span>
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-2">{plan.name}</h3>
                <div className="flex items-end gap-1 mb-2">
                  <span className="text-4xl font-black text-gray-900">{plan.price}</span>
                  <span className="text-gray-400 text-sm mb-1">/{plan.period}</span>
                </div>
                <p className="text-gray-500 text-sm">{plan.desc}</p>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((f, j) => (
                  <li key={j} className="flex items-center gap-2.5">
                    {f.ok ? (
                      <svg className="w-4 h-4 text-emerald-500 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    ) : (
                      <svg className="w-4 h-4 text-gray-300 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    )}
                    <span className={`text-sm ${f.ok ? "text-gray-700" : "text-gray-300"}`}>{f.text}</span>
                  </li>
                ))}
              </ul>

              <button
                className={`w-full py-3.5 rounded-xl font-semibold text-sm transition-all active:scale-95 ${plan.ctaStyle}`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>

        {/* Note */}
        <p className="text-center text-gray-400 text-sm mt-8">
          * As taxas de reserva são cobradas sobre o valor de cada transação realizada na plataforma.
          Para motoristas, não há custo de cadastro ou assinatura.
        </p>
      </div>
    </section>
  );
}
