const listings = [
  {
    id: 1,
    title: "Garagem Coberta – Pinheiros",
    city: "São Paulo, SP",
    type: "Coberta",
    price: 12,
    priceUnit: "/hora",
    rating: 4.9,
    reviews: 134,
    available: true,
    tags: ["24h", "Câmeras", "Iluminada"],
    color: "from-emerald-400 to-teal-500",
    emoji: "🏠",
  },
  {
    id: 2,
    title: "Vaga no Subsolo – Copacabana",
    city: "Rio de Janeiro, RJ",
    type: "Subsolo",
    price: 15,
    priceUnit: "/hora",
    rating: 4.8,
    reviews: 89,
    available: true,
    tags: ["Câmeras", "Portaria 24h", "Coberta"],
    color: "from-blue-400 to-indigo-500",
    emoji: "🌊",
  },
  {
    id: 3,
    title: "Estacionamento Privativo – Savassi",
    city: "Belo Horizonte, MG",
    type: "Descoberta",
    price: 8,
    priceUnit: "/hora",
    rating: 4.7,
    reviews: 56,
    available: true,
    tags: ["Câmeras", "App de acesso"],
    color: "from-purple-400 to-violet-500",
    emoji: "⛰️",
  },
  {
    id: 4,
    title: "Garagem Individual – Batel",
    city: "Curitiba, PR",
    type: "Coberta",
    price: 9,
    priceUnit: "/hora",
    rating: 5.0,
    reviews: 203,
    available: false,
    tags: ["24h", "Câmeras", "Portão automático"],
    color: "from-orange-400 to-rose-500",
    emoji: "🌲",
  },
];

// Listing card helper
function ListingCard({ listing }: { listing: typeof listings[0] }) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:border-emerald-100 transition-all group cursor-pointer">
      {/* Image Area */}
      <div className={`relative h-44 bg-gradient-to-br ${listing.color} flex items-center justify-center`}>
        <span className="text-6xl opacity-80">{listing.emoji}</span>
        <div className="absolute top-3 left-3">
          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
            listing.available
              ? "bg-emerald-500 text-white"
              : "bg-gray-400 text-white"
          }`}>
            {listing.available ? "✓ Disponível" : "× Ocupada"}
          </span>
        </div>
        <div className="absolute top-3 right-3">
          <button className="w-8 h-8 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center hover:bg-white/40 transition-colors">
            <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div>
            <h3 className="font-bold text-gray-900 text-sm group-hover:text-emerald-600 transition-colors leading-tight">
              {listing.title}
            </h3>
            <div className="flex items-center gap-1 mt-0.5 text-gray-400 text-xs">
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              </svg>
              {listing.city}
            </div>
          </div>
          <div className="text-right shrink-0 ml-2">
            <div className="text-emerald-600 font-black text-lg">R$ {listing.price}</div>
            <div className="text-gray-400 text-xs">{listing.priceUnit}</div>
          </div>
        </div>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-3">
          <svg className="w-3.5 h-3.5 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
          <span className="text-xs font-semibold text-gray-700">{listing.rating}</span>
          <span className="text-xs text-gray-400">({listing.reviews} avaliações)</span>
          <span className="mx-1 text-gray-200">•</span>
          <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">{listing.type}</span>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {listing.tags.map((tag) => (
            <span key={tag} className="text-xs bg-gray-50 border border-gray-100 text-gray-500 px-2 py-0.5 rounded-full">
              {tag}
            </span>
          ))}
        </div>

        <button
          disabled={!listing.available}
          className={`w-full py-2.5 rounded-xl text-sm font-semibold transition-all active:scale-95 ${
            listing.available
              ? "bg-emerald-500 hover:bg-emerald-600 text-white shadow-md hover:shadow-emerald-200"
              : "bg-gray-100 text-gray-400 cursor-not-allowed"
          }`}
        >
          {listing.available ? "Reservar Agora" : "Indisponível"}
        </button>
      </div>
    </div>
  );
}

export default function FeaturedListings() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div>
            <span className="inline-block text-emerald-600 font-semibold text-sm uppercase tracking-widest mb-3">
              Vagas em Destaque
            </span>
            <h2 className="text-4xl font-black text-gray-900">
              Vagas populares agora
            </h2>
          </div>
          <a
            href="#"
            className="text-emerald-600 font-semibold text-sm hover:text-emerald-700 flex items-center gap-1.5 transition-colors shrink-0"
          >
            Ver todas as vagas
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </a>
        </div>

        {/* Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {listings.map((listing) => (
            <ListingCard key={listing.id} listing={listing} />
          ))}
        </div>
      </div>
    </section>
  );
}
