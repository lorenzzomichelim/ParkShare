import { useState } from "react";

const faqs = [
  {
    q: "O cadastro é realmente gratuito?",
    a: "Sim! Cadastrar sua vaga na plataforma é 100% gratuito. Cobramos apenas uma taxa de serviço sobre cada reserva concluída com sucesso. Não há mensalidade obrigatória no plano básico.",
  },
  {
    q: "Como funciona o pagamento para proprietários?",
    a: "Após cada reserva concluída, o valor é creditado na sua carteira virtual do ParkShare. Você pode sacar via PIX a qualquer momento, com processamento em até 24 horas úteis.",
  },
  {
    q: "E se o motorista danificar minha vaga ou garagem?",
    a: "Todas as reservas incluem seguro contra danos à estrutura da vaga. Em caso de incidente, você aciona o suporte com fotos e o processo de ressarcimento é iniciado em até 48 horas.",
  },
  {
    q: "Posso bloquear datas em que vou usar minha vaga?",
    a: "Claro! Você tem controle total da disponibilidade. Basta acessar o app e bloquear os dias ou horários em que precisar usar a vaga. Não há penalidade por isso.",
  },
  {
    q: "Como o motorista acessa a vaga?",
    a: "Após a confirmação da reserva, o motorista recebe o endereço completo, instruções de acesso (código, interfone, etc.) e o seu contato. Você também recebe os dados do motorista.",
  },
  {
    q: "Posso anunciar vaga de condomínio?",
    a: "Sim, desde que você seja o titular da vaga e respeite as regras do seu condomínio. Recomendamos verificar o regulamento interno antes de anunciar.",
  },
  {
    q: "Como o ParkShare verifica os motoristas?",
    a: "Todo motorista passa por verificação de CPF, e-mail e número de celular. Para reservas de longa duração, solicitamos também foto da CNH. Todos os pagamentos são processados digitalmente, criando rastreabilidade.",
  },
  {
    q: "Posso cancelar uma reserva?",
    a: "Sim. Motoristas podem cancelar com reembolso total até 2 horas antes do início da reserva. Após isso, aplicamos uma taxa de cancelamento. Proprietários podem cancelar em emergências sem penalidade.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <section id="faq" className="py-24 bg-gray-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block text-emerald-600 font-semibold text-sm uppercase tracking-widest mb-3">
            Perguntas Frequentes
          </span>
          <h2 className="text-4xl font-black text-gray-900 mb-4">
            Ainda tem dúvidas?
          </h2>
          <p className="text-lg text-gray-500">
            Respondemos as perguntas mais comuns sobre o ParkShare.
          </p>
        </div>

        {/* Accordion */}
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className={`bg-white rounded-2xl border transition-all overflow-hidden ${
                open === i ? "border-emerald-300 shadow-md" : "border-gray-100 hover:border-gray-200"
              }`}
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between px-6 py-5 text-left"
              >
                <span className="font-semibold text-gray-900 text-sm pr-4">{faq.q}</span>
                <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 transition-all ${
                  open === i ? "bg-emerald-500 rotate-45" : "bg-gray-100"
                }`}>
                  <svg className={`w-3.5 h-3.5 ${open === i ? "text-white" : "text-gray-600"}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
                  </svg>
                </div>
              </button>
              {open === i && (
                <div className="px-6 pb-5">
                  <p className="text-gray-500 text-sm leading-relaxed">{faq.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Support CTA */}
        <div className="mt-12 text-center bg-white rounded-2xl border border-gray-100 p-8">
          <div className="text-3xl mb-3">💬</div>
          <h3 className="font-bold text-gray-900 mb-2">Não encontrou sua resposta?</h3>
          <p className="text-gray-500 text-sm mb-4">Nosso time de suporte está disponível 24/7 para te ajudar.</p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a href="#" className="inline-flex items-center justify-center gap-2 border border-gray-200 hover:bg-gray-50 text-gray-700 font-medium px-5 py-2.5 rounded-xl text-sm transition-colors">
              📧 Enviar e-mail
            </a>
            <a href="#" className="inline-flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-medium px-5 py-2.5 rounded-xl text-sm transition-colors">
              💬 Chat ao vivo
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
