export default function CTA() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative bg-gradient-to-br from-emerald-500 via-emerald-600 to-teal-700 rounded-3xl p-12 md:p-16 overflow-hidden text-center shadow-2xl shadow-emerald-200">
          {/* Decorative blobs */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-black/10 rounded-full translate-y-1/2 -translate-x-1/2" />
          <div className="absolute top-1/2 left-1/4 w-32 h-32 bg-white/5 rounded-full -translate-y-1/2" />

          <div className="relative">
            <div className="text-5xl mb-4">🚀</div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-4 leading-tight">
              Pronto para começar?
            </h2>
            <p className="text-emerald-100 text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
              Junte-se a mais de 50.000 brasileiros que já estão usando o ParkShare.
              Cadastre sua vaga grátis ou encontre a vaga perfeita agora.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="#"
                className="inline-flex items-center justify-center gap-2 bg-white hover:bg-gray-50 text-emerald-600 font-bold px-8 py-4 rounded-2xl text-base transition-all shadow-xl hover:shadow-2xl active:scale-95"
              >
                💰 Cadastrar Minha Vaga
              </a>
              <a
                href="#"
                className="inline-flex items-center justify-center gap-2 bg-white/20 hover:bg-white/30 border border-white/30 text-white font-bold px-8 py-4 rounded-2xl text-base transition-all backdrop-blur-sm active:scale-95"
              >
                🚗 Encontrar Vaga
              </a>
            </div>

            <p className="text-emerald-200/70 text-xs mt-6">
              Sem cartão de crédito • Cadastro em menos de 5 minutos • Cancele quando quiser
            </p>
          </div>
        </div>

        {/* App store badges */}
        <div className="mt-12 text-center">
          <p className="text-gray-400 text-sm mb-6">Também disponível no seu celular</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a href="#" className="flex items-center gap-3 bg-gray-900 hover:bg-gray-800 text-white px-6 py-3.5 rounded-2xl transition-all group">
              <svg className="w-7 h-7" viewBox="0 0 24 24" fill="currentColor">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
              </svg>
              <div className="text-left">
                <div className="text-xs text-gray-400">Baixar na</div>
                <div className="text-sm font-semibold">App Store</div>
              </div>
            </a>
            <a href="#" className="flex items-center gap-3 bg-gray-900 hover:bg-gray-800 text-white px-6 py-3.5 rounded-2xl transition-all group">
              <svg className="w-7 h-7" viewBox="0 0 24 24" fill="currentColor">
                <path d="M3.18 23.76A2 2 0 012 22V2a2 2 0 011.18-1.76l11.65 11.65L3.18 23.76zm13.64-7.34l-2.39-1.38-2.5 2.5 4.89 2.76v.01l2.39-1.38a2 2 0 000-3.46l-2.39-1.05zm0-9.84L4.93 1.06v.01L3.18.24A2 2 0 012 2v.09l9.77 9.77 2.5 2.5 2.55-2.55-2.39-1.38zM22 10.55a2 2 0 00-1.09-1.77l-2.39-1.38-2.67 2.67 2.67 2.67 2.39-1.38A2 2 0 0022 10.55z" />
              </svg>
              <div className="text-left">
                <div className="text-xs text-gray-400">Disponível no</div>
                <div className="text-sm font-semibold">Google Play</div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
